import React from "react";

let pokemonsHTML = [];

/*function makePokemonArray(numberOfPokemons, pokemons) {
    for(let i = 0; i < numberOfPokemons; ++i){
        pokemonsHTML.push(<li>pokemons[i].name</li>)
    }

    return pokemonsHTMLk
}*/


const AdminPokemonPresentation = ( {pokemons} ) =>
    /*<table>
        <tr>
            <th>Name</th>
            <th>Picture</th>
            <th></th>
        </tr>
        
        {pokemons.map(function (row, i) {
            return (
                <tr>
                    <td>{row.name}</td>
                    <td><img src={row.photo} /></td>
                    <td><input type="button" value="DELETE"/></td>
                </tr>
            )
        })}
        
    </table>

    */
    <div className="container">
        {pokemons.map(function(row, i){
            return (
                <div className="row">
                    <div className="col-xs-6 col-md-5">
                        <h5>{row.name}</h5>
                    </div>
                    <div className="col-xs-6 col-md-5">
                        <img src={row.photo} />
                    </div>

                    <div>
                        <button>DELETE</button>
                    </div>
                </div>
            )
        })}
    </div>


export default AdminPokemonPresentation;