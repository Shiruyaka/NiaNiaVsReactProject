import React from "react";


const ParallaxPres = ( {}) => {

    return (
            <div className="parallax"></div>
    );
};

export default ParallaxPres;