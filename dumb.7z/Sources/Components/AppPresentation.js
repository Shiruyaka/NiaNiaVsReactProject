import React from "react";
import { Header, SignUpDialog, Menu, AdminPokemons, AddPokemonAdmin } from "./Containers"

import { connect } from "react-redux"

const AppPresentation = ( {user, activePage = "", logged = false, wrongLoginOrPassword = false, show_sign_up_dialog = false, accountCreated=false}) => {

    return (

        <div className="parallax">


            <Header/>
            <div className="row">

                <div className="col-md-2 offset-lg-2 center-block"> {(logged)? <Menu/> : null} </div>
                <div className="col-md-8 col-lg-8 center-block ">

                    {(show_sign_up_dialog) ? <SignUpDialog/> : null}
                    {(accountCreated) ? <p className="bg-success">Account created, now you can log in</p> : null }
                    {(wrongLoginOrPassword)? <p className="bg-danger">Invalid username or login</p>: null }
                    {(user !== undefined && user.role === "admin" &&  activePage === "PokemonAdmin") ? <AdminPokemons/>: null }
                    {(user !== undefined && user.role === "admin" &&  activePage === "AddPokemonAdmin") ? <AddPokemonAdmin/>: null }
                </div>

            </div>
        </div>
    );
};

export default AppPresentation;